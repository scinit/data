Title: TSEMTA: A Tripartite Shared Evolutionary Multi-Task Algorithm for Optimizing Many-Task Vehicle Routing Problems
Author: Yanguang Cai, Yanlin Wu, Chuncheng Fang