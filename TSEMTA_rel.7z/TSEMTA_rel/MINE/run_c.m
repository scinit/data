function run_c()

    clc; clear; close all;
    warning('off', 'all')
    disp(datetime);
    rng(1);

    [comm, res, conv] = init_paras();

    for i = 1:comm.probs
        info = read_data(i, comm);
        [res(:, :, i), conv(:, :, i)] = run_task(i, info, comm);
    end

end

function [fit, cv] = run_task(i, info, comm)

    fit = zeros(comm.tasks, comm.runs);
    cv = zeros(comm.max_gen, comm.runs);

    for j = 1:comm.runs
        [fit(:, j), cv(:, j)] = run_one(i, info, comm, j);
    end

end

function [fitj, cvj] = run_one(i, info, comm, runj)

    pop = init_pop(info, comm);
    ps = init_ps(info, pop);

    cvj = zeros(comm.max_gen, 1);

    for gen = 1:comm.max_gen

        tic;

        if mod(gen, ps.ten) == 1
            ccumFb = zeros(1, comm.tasks);

        elseif mod(gen, ps.ten) == 2
            curFb = arrayfun(@(x) min(x.fit), pop);
            ccumFb = abs(preFb - curFb) ./ (preFb +1);

        elseif mod(gen, ps.ten) > 2 || mod(gen, ps.ten) == 0
            curFb = arrayfun(@(x) min(x.fit), pop);
            diffFb = abs(preFb - curFb) ./ (preFb + 1);

            diffFb(diffFb < ccumFb) = 0;
            ccumFb = ccumFb + diffFb;

        end

        preFb = arrayfun(@(x) min(x.fit), pop);

        [pop, ps] = eva_task(pop, comm, info, ps, gen, ccumFb);

        [ps, pop] = trans(pop, info, comm, gen, ps);

        cvj(gen) = mean(arrayfun(@(x) min(x.fit), pop));

        fprintf('prob: %d, run:%d, gen: %d, avg fit: %.2f, used time: %.2fs\n', ...
            i, runj, gen, cvj(gen), toc);

    end

    fitj = arrayfun(@(x) min(x.fit), pop);

    fitj = fitj';

end

function [ps, pop] = trans(pop, info, comm, gen, ps)

    mod_gen = mod(gen, ps.ten);

    shapeVector = repmat(1:ps.subtasks, 1, ps.type_num);

    if mod_gen == 5

        [ps, selected_tasks] = roulette_type_task(ps, arrayfun(@(x) min(x.fit), pop), arrayfun(@(x) mean(x.fit), pop));
        ps.preFit = arrayfun(@(x) min(x.fit), pop);
        ps.preMeanFit = arrayfun(@(x) mean(x.fit), pop);

        best_vrp_idx = ones(comm.tasks, comm.tasks);

        for t = 1:ps.type_num

            for jj = (t - 1) * ps.subtasks + 1:t * ps.subtasks
                j = selected_tasks(jj);

                for ix = (t - 1) * ps.subtasks + 1:t * ps.subtasks

                    if ix == j
                        continue
                    end

                    best_k = sum(pop(j).vrp(best_vrp_idx(ix, j), :) == 1) - 1;

                    ix_t = shapeVector(ix);
                    j_t = shapeVector(j);

                    M_ix2j = sprintf('%sM_%s_%d_%d_%s_%d_%d.txt', info(ix).m_path, info(ix).srcfname, t * ps.subtasks, ix_t, info(ix).srcfname, t * ps.subtasks, j_t);

                    tvrp = pop(ix).vrp(best_vrp_idx(ix, j), :);

                    indi.tsp = transfer_op(best_k, tvrp, info(ix), load(M_ix2j));

                    [indi.vrp, indi.fit] = split(indi.tsp, info(j));

                    if rand < ps.lspa
                        indi = local_search(indi, info(j));
                    end

                    pop(j) = add_pop(indi, pop(j));

                    best_vrp_idx(ix, j) = best_vrp_idx(ix, j) + 1;

                end

            end

        end

    elseif mod_gen == 0

        [ps, selected_tasks] = roulette_task(ps, arrayfun(@(x) min(x.fit), pop), arrayfun(@(x) mean(x.fit), pop));
        ps.preFit = arrayfun(@(x) min(x.fit), pop);
        ps.preMeanFit = arrayfun(@(x) mean(x.fit), pop);

        best_vrp_idx = ones(comm.tasks, comm.tasks);

        for jj = 1:comm.tasks
            j = selected_tasks(jj);

            for ix = 1:comm.tasks

                if ix == j
                    continue
                end

                best_k = sum(pop(j).vrp(best_vrp_idx(ix, j), :) == 1) - 1;

                ix_type = ceil(ix / ps.subtasks) * ps.subtasks;
                ix_t = shapeVector(ix);

                j_type = ceil(j / ps.subtasks) * ps.subtasks;
                j_t = shapeVector(j);

                M_ix2j = sprintf('%sM_%s_%d_%d_%s_%d_%d.txt', info(ix).m_path, info(ix).srcfname, ix_type, ix_t, info(ix).srcfname, j_type, j_t);

                tvrp = pop(ix).vrp(best_vrp_idx(ix, j), :);

                indi.tsp = transfer_op(best_k, tvrp, info(ix), load(M_ix2j));

                [indi.vrp, indi.fit] = split(indi.tsp, info(j));

                if rand < ps.lspa
                    indi = local_search(indi, info(j));
                end

                pop(j) = add_pop(indi, pop(j));

                best_vrp_idx(ix, j) = best_vrp_idx(ix, j) + 1;

            end

        end

    end

end

function tsp = transfer_op(k, vrp, info_ix, M)
    dist = get_dis_mat(vrp, info_ix);
    xt = get_multiDimension_scaling(dist);
    xr = xt * M;
    tsp = k_means(xr, k);
end

function tsp = k_means(xr, k)

    cust_size = size(xr, 2);
    % cust_size_half=ceil(cust_size/2);
    k = min(k, cust_size);

    [idx, ~] = kmeans(xr', k, 'MaxIter', 10, 'Display', 'off');
    idx = idx';
    % c=c';
    sets = zeros(k, cust_size);

    for i = 1:k
        t = find(idx == i);
        sets(i, 1:length(t)) = t;
    end

    feature_dis = squareform(pdist(xr'));

    pre_idx = 1;
    tsp = zeros(1, cust_size);

    for i = 1:k
        c_detail = sets(i, :);
        c_detail(c_detail == 0) = [];
        c_detail_size = length(c_detail);

        lr_top = [0; c_detail_size + 1];
        tsp_lr = zeros(c_detail_size, 1);

        while length(c_detail) > 1
            sub_cust_dis = feature_dis(c_detail, c_detail);

            [~, index] = max(sub_cust_dis(:));
            [row, col] = ind2sub(size(sub_cust_dis), index);
            l_r = sort(c_detail([row, col]));

            if lr_top(1) > 0 && feature_dis(l_r(1), tsp_lr(lr_top(1))) ...
                    +feature_dis(l_r(2), tsp_lr(lr_top(2))) ...
                    > feature_dis(l_r(1), tsp_lr(lr_top(2))) ...
                    +feature_dis(l_r(2), tsp_lr(lr_top(1)))

                l_r([1 2]) = l_r([2 1]);
            end

            lr_top(1) = lr_top(1) + 1;
            lr_top(2) = lr_top(2) - 1;

            tsp_lr(lr_top) = l_r;

            c_detail(ismember(c_detail, l_r)) = [];

        end

        if length(c_detail) == 1
            lr_top(1) = lr_top(1) + 1;
            tsp_lr(lr_top(1)) = c_detail(1);
        end

        tsp(pre_idx:pre_idx + c_detail_size - 1) = tsp_lr;
        pre_idx = pre_idx + c_detail_size;
    end

    tsp = [1 tsp + 1];
end

function xt = get_multiDimension_scaling(dist)

    EPS = 0.001;

    n = size(dist, 2);
    H = eye(n) - ones(n, n) / n;
    B = -H * dist .^ 2 * H / 2;
    B = (B + B') / 2;
    [eig_vec, eig_val] = eig(B);
    eig_val = diag(eig_val);

    feature_num = sum(eig_val > EPS);
    eig_val(eig_val <= EPS) = 0;

    eig_val = diag(eig_val);
    x = eig_vec * sqrt(eig_val);

    xt = x(:, any(abs(x) > EPS, 1));

    if size(xt, 2) < feature_num
        xt = [xt, zeros(n, feature_num - size(xt, 2))];
    end

    xt = xt';
end

function dist = get_dis_mat(vrp, info_tj)
    cust_size = info_tj.cust_num;
    alpha = info_tj.expand_rate;
    beta = info_tj.big_dis;

    vrp(vrp == 0) = [];

    dist = ones(cust_size) .* beta;
    dist(1:cust_size + 1:end) = 0;

    pos_depot = find(vrp == 1);

    for i = 2:length(pos_depot)
        ptl = pos_depot(i - 1);
        ptr = pos_depot(i);

        for j = ptl + 1:ptr - 1

            for k = j + 1:ptr - 1
                pos_l = vrp(j) - 1;
                pos_r = vrp(k) - 1;
                dist(pos_l, pos_r) = alpha .* (k - j);
                dist(pos_r, pos_l) = dist(pos_l, pos_r);
            end

        end

    end

end

function [pop, ps] = eva_task(pop, comm, info, ps, gen, ccumFb)

    mod_gen = mod(gen, ps.ten);

    if mod_gen == 5 || mod_gen == 9
        [ps, selected_tasks] = roulette_Rtype_task(ps, arrayfun(@(x) min(x.fit), pop), arrayfun(@(x) mean(x.fit), pop), pop);

    elseif mod_gen == 0
        [ps, selected_tasks] = roulette_R_task(ps, arrayfun(@(x) min(x.fit), pop), pop, ccumFb);

    else
        selected_tasks = 1:comm.tasks;

    end

    for tj = 1:comm.tasks
        j = selected_tasks(tj);
        pop(j) = search(pop(j), info(j), ps);
    end

end

function [ps, selected_tasks] = roulette_R_task(ps, current_fit, pop, ccumFb)

    pa1 = abs(ps.preFit - current_fit) ./ (ps.preFit + 1);

    omg4 = 0.9;
    Ib = omg4 * pa1 + (1 - omg4) * ccumFb;

    [~, i1] = sort(Ib);
    [~, Rib] = sort(i1);

    pa = (1 ./ Rib) ./ sum(1 ./ Rib);

    pa = cumsum(pa);
    pa(end) = 1;

    selected_tasks = zeros(length(pa), 1);
    ind = 1;

    for i = 1:length(pa)
        selected_tasks(ind) = find(rand <= pa, 1);
        ind = ind + 1;
    end

end

function [ps, selected_tasks] = roulette_Rtype_task(ps, current_fit, mean_fit, pop)
    ind = 1;
    selected_tasks = zeros(length(current_fit), 1);

    for tid = 1:ps.type_num
        idx = (tid - 1) * ps.subtasks + 1:tid * ps.subtasks;

        pa1 = abs(ps.preFit(idx) - current_fit(idx)) ./ (ps.preFit(idx) + 1);
        pa2 = abs(ps.preMeanFit(idx) - mean_fit(idx)) ./ (ps.preMeanFit(idx) + 1);

        omg1 = 0.5;
        Icur = omg1 * pa1 + (1 - omg1) * pa2;

        [~, i1] = sort(Icur);
        [~, Ricur] = sort(i1);

        Rpa2 = zeros(1, length(idx));

        for idx_i = 1:length(idx)
            Rpa2(idx_i) = sum(pop(idx_i).fit < ps.prePop(idx_i).fit);
        end

        [~, i1] = sort(Rpa2);
        [~, Rn] = sort(i1);

        Rcur = Ricur + Rn;

        omg3 = 0.5;
        Radj = omg3 * Rcur + (1 - omg3) * ps.preR(tid, :);

        pa = (1 ./ Radj) ./ (sum(1 ./ Radj));

        pa = cumsum(pa);
        pa(end) = 1;

        for i = 1:length(pa)
            selected_tasks(ind) = find(rand <= pa, 1) + (tid - 1) * ps.subtasks;
            ind = ind + 1;
        end

        ps.preR(tid, :) = Rcur;

    end

end

function [ps, selected_tasks] = roulette_type_task(ps, current_fit, mean_fit)

    ind = 1;
    selected_tasks = zeros(length(current_fit), 1);

    for tid = 1:ps.type_num
        idx = (tid - 1) * ps.subtasks + 1:tid * ps.subtasks;

        pa1 = abs(ps.preFit(idx) - current_fit(idx)) ./ (ps.preFit(idx) + 1);
        pa2 = abs(ps.preMeanFit(idx) - mean_fit(idx)) ./ (ps.preMeanFit(idx) + 1);

        omg1 = 0.5;
        Icur = omg1 * pa1 + (1 - omg1) * pa2;

        omg2 = 0.9;
        Iadj = omg2 * Icur + (1 - omg2) * ps.preI(tid, :);

        pa = Iadj ./ sum(Iadj);

        pa = cumsum(pa);
        pa(end) = 1;

        for i = 1:length(pa)
            selected_tasks(ind) = find(rand <= pa, 1) + (tid - 1) * ps.subtasks;
            ind = ind + 1;
        end

        ps.preI(tid, :) = Icur;

    end

end

function [ps, selected_tasks] = roulette_task(ps, current_fit, current_mean_fit)

    pa1 = abs(ps.preFit - current_fit) ./ (ps.preFit + 1);
    pa2 = abs(ps.preMeanFit - current_mean_fit) ./ (ps.preMeanFit + 1);

    omg1 = 0.5;
    Icur = omg1 * pa1 + (1 - omg1) * pa2;

    omg2 = 0.9;
    Itype = omg2 * Icur + (1 - omg2) * ps.preGI;

    pa = Itype ./ sum(Itype);

    pa = cumsum(pa);
    pa(end) = 1;

    selected_tasks = zeros(length(current_fit), 1);

    for i = 1:length(current_fit)
        selected_tasks(i) = find(rand <= pa, 1);
    end

    ps.preGI = Icur;

end

function popj = search(popj, infoj, ps)

    isEliteLs = zeros(1, ps.nums);

    for k = 1:infoj.pop_size

        ptid = select_parent(k, ps.nums, infoj.pop_size);

        indi.tsp = crossover(popj.tsp(ptid(1), :), popj.tsp(ptid(2), :));

        [indi.vrp, indi.fit] = split(indi.tsp, infoj);

        if rand <= ps.lspa

            if rand <= ps.lsshare && sum(isEliteLs) < ps.nums

                [isEliteLs, elite_indi] = build_elite_indi(popj, ps, isEliteLs);
                indi = local_search(elite_indi, infoj);

                im_idx = 1;

                while indi.fit == elite_indi.fit && im_idx <= ps.nums

                    [isEliteLs, elite_indi] = build_elite_indi(popj, ps, isEliteLs);
                    indi = local_search(elite_indi, infoj);

                    im_idx = im_idx + 1;
                end

            else

                indi = local_search(indi, infoj);

            end

        end

        popj = add_pop(indi, popj);

    end

end

function [isEliteLs, elite_indi] = build_elite_indi(popj, ps, isEliteLs)

    elite_idx = randi(ps.nums, 1);

    while isEliteLs(elite_idx) == 1
        elite_idx = randi(ps.nums, 1);

        if sum(isEliteLs) >= ps.nums
            break
        end

    end

    isEliteLs(elite_idx) = 1;

    elite_indi.tsp = popj.tsp(elite_idx, :);
    elite_indi.vrp = popj.vrp(elite_idx, :);
    elite_indi.fit = popj.fit(elite_idx, :);

end

function popj = add_pop(indi, popj)

    current_size = length(popj.fit);
    rep_idx = round(current_size / 2 + randi(current_size / 2, 1));

    diff_flag = true;
    diff_abs = abs(popj.fit - indi.fit);
    diff_abs(rep_idx) = [];

    if min(diff_abs) < 0.2
        diff_flag = false;
    end

    if indi.fit < popj.fit(1) || diff_flag

        try
            popj.tsp(rep_idx, :) = indi.tsp;
        catch exception
            disp(indi.tsp);
            disp(getReport(exception));

            popj.tsp(rep_idx, :) = unique(indi.tsp(indi.tsp >= 1), 'stable');

        end

        popj.vrp(rep_idx, :) = indi.vrp;
        popj.fit(rep_idx) = indi.fit;

        popj = sort_pop(popj);

    end

end

function indi = local_search(indi, infoj)

    out_ls_limit = 3;
    max_improve = 5;

    for count = 1:out_ls_limit

        indi = replace(indi, infoj, max_improve);

        if indi.state == 1
            continue
        end

        indi = single_insert(indi, infoj, max_improve);

        if indi.state == 1
            continue
        end

        indi = two_two_swap(indi, infoj, max_improve);

        if indi.state == 1
            continue
        end

        break

    end

end

function indi = two_two_swap(indi, infoj, max_improve)

    init_fit = indi.fit;
    indi.state = 0;
    vrp = indi.vrp(indi.vrp ~= 0);
    best_fit = indi.fit;

    for count = 1:max_improve
        mark = 0;

        for i = 2:length(vrp) - 3

            for j = i + 1:length(vrp) - 2
                temp_vrp = four_swap(vrp, i, j);
                [new_vrp, current_fit] = nosplit(temp_vrp, infoj, best_fit);

                if current_fit < best_fit
                    vrp = new_vrp(new_vrp ~= 0);
                    best_fit = current_fit;

                    mark = 1;
                    break
                end

            end

            if mark == 1
                break
            end

        end

        if mark == 0
            break
        end

    end

    indi.tsp = [1 vrp(vrp ~= 1)];
    indi.vrp = [vrp zeros(1, infoj.route_len - length(vrp))];
    indi.fit = best_fit;

    if best_fit < init_fit
        indi.state = 1;
    end

end

function vrp = four_swap(vrp, i, j)
    vrp([i, j]) = vrp([j, i]);
    vrp([i + 1, j + 1]) = vrp([j + 1, i + 1]);
end

function indi = single_insert(indi, infoj, max_improve)

    init_fit = indi.fit;
    indi.state = 0;
    vrp = indi.vrp(indi.vrp ~= 0);
    best_fit = indi.fit;

    for count = 1:max_improve
        mark = 0;

        for i = 2:length(vrp) - 2

            for j = i + 1:length(vrp) - 1
                temp_vrp = insert_ele(vrp, i, j);
                [new_vrp, current_fit] = nosplit(temp_vrp, infoj, best_fit);

                if current_fit < best_fit
                    vrp = new_vrp(new_vrp ~= 0);
                    best_fit = current_fit;

                    mark = 1;
                    break
                end

            end

            if mark == 1
                break
            end

        end

        if mark == 0
            break
        end

    end

    indi.tsp = [1 vrp(vrp ~= 1)];
    indi.vrp = [vrp zeros(1, infoj.route_len - length(vrp))];
    indi.fit = best_fit;

    if best_fit < init_fit
        indi.state = 1;
    end

end

function seq = insert_ele(seq, i, j)
    seq = [seq(1:j - 1) seq(i) seq(j:end)];
    seq(i) = [];
end

function indi = replace(indi, infoj, max_improve)
    init_fit = indi.fit;
    indi.state = 0;
    vrp = indi.vrp(indi.vrp ~= 0);
    best_fit = indi.fit;

    for count = 1:max_improve
        mark = 0;

        for i = 2:length(vrp) - 2

            for j = i + 1:length(vrp) - 1
                temp_vrp = swap_vrp(vrp, i, j);
                [new_vrp, current_fit] = nosplit(temp_vrp, infoj, best_fit);

                if current_fit < best_fit
                    vrp = new_vrp(new_vrp ~= 0);
                    best_fit = current_fit;

                    mark = 1;
                    break
                end

            end

            if mark == 1
                break
            end

        end

        if mark == 0
            break
        end

    end

    indi.tsp = [1 vrp(vrp ~= 1)];
    indi.vrp = [vrp zeros(1, infoj.route_len - length(vrp))];
    indi.fit = best_fit;

    if best_fit < init_fit
        indi.state = 1;
    end

end

function vrp = swap_vrp(vrp, i, j)
    vrp([i, j]) = vrp([j, i]);
end

function [new_vrp, current_fit] = nosplit(temp_vrp, infoj, best_fit)

    dis = infoj.distance;
    cg = infoj.cg;
    tw = infoj.time_window;
    sertime = infoj.service_time;

    fuel = infoj.fuel_cap * infoj.fix_fuel_rate;
    swap_time = 5;

    temp_demand = 0;
    temp_fuel = 0;
    ar_time = 0;
    temp_dis = 0;

    for i = 1:length(temp_vrp) - 1

        if temp_vrp(i) ~= 1
            temp_demand = temp_demand + infoj.demand(temp_vrp(i));

            temp_fuel = temp_fuel + dis(temp_vrp(i), temp_vrp(i + 1));

            if temp_fuel > fuel
                temp_fuel = cg.dis_right(temp_vrp(i), temp_vrp(i + 1));

                ar_time = ar_time + cg.ndis_charge(temp_vrp(i), temp_vrp(i + 1)) + swap_time;

                temp_dis = temp_dis + cg.ndis_charge(temp_vrp(i), temp_vrp(i + 1));
            else
                ar_time = ar_time + dis(temp_vrp(i), temp_vrp(i + 1));

                temp_dis = temp_dis + dis(temp_vrp(i), temp_vrp(i + 1));
            end

            ar_time = max(ar_time, tw(temp_vrp(i + 1), 1));

            if ar_time > tw(temp_vrp(i + 1), 2)
                current_fit = best_fit;
                new_vrp = temp_vrp;
                return
            else
                ar_time = ar_time + sertime(temp_vrp(i + 1));
            end

        else

            if temp_demand > infoj.capacity ...
                    || temp_dis > infoj.travelcon

                current_fit = best_fit;
                new_vrp = temp_vrp;
                return
            else
                temp_demand = 0;
                temp_dis = dis(temp_vrp(i), temp_vrp(i + 1));
                temp_fuel = temp_dis;

                ar_time = max(temp_dis, tw(temp_vrp(i + 1), 1));

                if ar_time > tw(temp_vrp(i + 1), 2)
                    current_fit = best_fit;
                    new_vrp = temp_vrp;
                    return
                else
                    ar_time = ar_time + sertime(temp_vrp(i + 1));
                end

            end

        end

    end

    if temp_demand > infoj.capacity ...
            || temp_dis > infoj.travelcon

        current_fit = best_fit;
        new_vrp = temp_vrp;
        return
    end

    new_vrp = temp_vrp;
    current_fit = 0;

    for i = 1:length(temp_vrp) - 1
        current_fit = current_fit + dis(temp_vrp(i), temp_vrp(i + 1));
    end

end

function child = crossover(p1, p2)

    if rand < 0.5
        [p1, p2] = deal(p2, p1);
    end

    p1(1) = [];
    p2(1) = [];

    p1_len = length(p1);

    ab = sort(randperm(p1_len, 2));

    if ab(end) - ab(1) + 1 == p1_len
        ab(1) = ab(1) + 1;
    end

    sub_p1 = p1(ab(1):ab(end));

    re_p2 = [p2(ab(end) + 1:end) p2(1:ab(end))];

    re_p2(ismember(re_p2, sub_p1)) = [];

    child = [re_p2(p1_len - ab(end) + 1:end) sub_p1 re_p2(1:p1_len - ab(end))];

    child = [1 child];

end

function ptid = select_parent(k, nums, pop_size)

    ptid = zeros(2, 1);

    if mod(k, nums) == 0
        ptid(1) = randperm(nums, 1);
    else
        ptid(1) = min(randperm(pop_size, 2));
    end

    ptid(2) = min(randperm(pop_size, 2));

    slt_num = 1;

    while ptid(1) == ptid(2) && slt_num < nums
        ptid(2) = min(randperm(pop_size, 2));
        slt_num = slt_num + 1;
    end

end

function ps = init_ps(info, pop)

    ps.type_num = 5;
    ps.subtasks = 10;

    ps.lspa = 0.1;
    ps.lsshare = 0.5;

    ps.ten = 10;

    ps.nums = fix(0.1 * info(1).pop_size);

    ps.preFit = arrayfun(@(x) min(x.fit), pop);
    ps.preMeanFit = arrayfun(@(x) mean(x.fit), pop);
    ps.preI = zeros(ps.type_num, ps.subtasks);
    ps.preGI = zeros(1, ps.type_num * ps.subtasks);

    ps.prePop = pop;
    ps.preR = zeros(ps.type_num, ps.subtasks);
    ps.preGR = zeros(1, ps.type_num * ps.subtasks);

end

function pop = init_pop(info, comm)
    pop(comm.tasks) = struct('tsp', [], 'vrp', [], 'fit', []);

    for j = 1:comm.tasks
        pop(j).tsp = zeros(info(j).pop_size, info(j).city_num);
        pop(j).vrp = zeros(info(j).pop_size, info(j).route_len);
        pop(j).fit = zeros(info(j).pop_size, 1);

        for k = 1:info(j).pop_size
            pop(j).tsp(k, :) = [1 randperm(info(j).cust_num) + 1];
            [pop(j).vrp(k, :), pop(j).fit(k)] = split(pop(j).tsp(k, :), info(j));
        end

        pop(j) = sort_pop(pop(j));
    end

end

function popj = sort_pop(popj)
    [popj.fit, idx] = sort(popj.fit);
    popj.tsp = popj.tsp(idx, :);
    popj.vrp = popj.vrp(idx, :);
end

function [vrp, fit] = split(tsp, infoi)

    dis = infoi.distance;
    demand = infoi.demand;
    tw = infoi.time_window;
    rt_time = infoi.travelcon;
    cp = infoi.capacity;
    city_num = infoi.city_num;
    sertime = infoi.service_time;
    cg = infoi.cg;
    swap_time = 5;

    fuel = infoi.fuel_cap * infoi.fix_fuel_rate;

    vrp = zeros(1, infoi.route_len);
    pre_lv_time = 0;
    delivery = 0;
    dis_fuel = 0;
    used_charge_num = 0;

    dri_dis = 0;

    k = 1;
    vrp(k) = 1;
    k = k + 1;

    for j = 2:city_num

        dis_fuel = dis_fuel + dis(vrp(k - 1), tsp(j));

        if dis_fuel > fuel
            ar_time = pre_lv_time + cg.ndis_charge(vrp(k - 1), tsp(j)) + swap_time;
            dis_fuel = cg.dis_right(vrp(k - 1), tsp(j));
            used_charge_num = used_charge_num + 1;

            temp_dri_dis = cg.ndis_charge(vrp(k - 1), tsp(j));
        else
            ar_time = pre_lv_time + dis(vrp(k - 1), tsp(j));

            temp_dri_dis = dis(vrp(k - 1), tsp(j));
        end

        sv_time = max(ar_time, tw(tsp(j), 1));
        delivery = delivery + demand(tsp(j));

        if sv_time > tw(tsp(j), 2) || delivery > cp || sv_time + sertime(tsp(j)) + dis(tsp(j), 1) > rt_time
            temp_dri_dis = dis(vrp(k - 1), 1) + dis(1, tsp(j));

            vrp(k) = 1;
            k = k + 1;
            ar_time = dis(1, tsp(j));
            sv_time = max(ar_time, tw(tsp(j), 1));
            delivery = demand(tsp(j));
            dis_fuel = dis(1, tsp(j));
        end

        vrp(k) = tsp(j);
        k = k + 1;
        pre_lv_time = sv_time + sertime(tsp(j));

        dri_dis = dri_dis + temp_dri_dis;
    end

    vrp(k) = 1;

    fit = dri_dis;

end

function info = read_data(i, comm)
    srcpath = 'D:/data/code/matlab_code/VRPpaper/TSEMTA_rel/data/evrptw_data/type-c/';
    srcfile_list = dir(fullfile(srcpath, '*.txt'));
    srcfnames = natsortfiles({srcfile_list.name});
    srcfname = srcfnames{i};

    info(length(comm.tasks)) = struct('fuel_cap', [], 'capacity', [], 'fuel_cons', [], 'recharge_rate', [], ...
        'avg_velocity', [], 'charge_num', [], 'charge_node', [], 'city', [], 'distance', [], ...
        'travelcon', [], 'demand', [], 'time_window', [], 'service_time', [], 'route_len', [], ...
        'expand_rate', [], 'big_dis', [], 'pop_size', [], 'city_num', [], 'cust_num', [], ...
        'fix_fuel_rate', [], 'm_path', [], 'subfname', [], 'cg', [], 'trans_set', []);

    taskpath = sprintf('D:/data/code/matlab_code/VRPpaper/TSEMTA_rel/data/P/type-c/C_P%d/', i);
    task_list = dir(fullfile(taskpath, '*.txt'));
    taskfnames = natsortfiles({task_list.name});

    srcinfo = load(sprintf('%s%s', srcpath, srcfname));

    for idx = 1:comm.tasks
        taskinfo = load(sprintf('%s%s', taskpath, taskfnames{idx}));

        info(idx).fuel_cap = srcinfo(end, 2);
        info(idx).capacity = srcinfo(end, 3);
        info(idx).fuel_cons = srcinfo(end, 4);
        info(idx).recharge_rate = srcinfo(end, 5);
        info(idx).avg_velocity = srcinfo(end, 6);

        info(idx).charge_num = 21;
        info(idx).charge_node = srcinfo(2:22, 2:3);

        info(idx).city = taskinfo(:, 2:3);
        info(idx).distance = squareform(pdist(info(idx).city));

        info(idx).travelcon = srcinfo(1, 6);
        info(idx).demand = taskinfo(:, 4);
        info(idx).time_window = [srcinfo(1, 5:6); taskinfo(2:end, 5:6)];
        info(idx).service_time = taskinfo(:, 7);

        info(idx).route_len = 1000;
        info(idx).expand_rate = 10;
        info(idx).big_dis = 1000;
        info(idx).pop_size = 50;
        info(idx).city_num = size(info(idx).city, 1);
        info(idx).cust_num = info(idx).city_num - 1;

        info(idx).fix_fuel_rate = (info(idx).cust_num - 50) / (90 - 50) * (2 - 1.5) + 1.5;

        info(idx).m_path = sprintf('D:/data/code/matlab_code/VRPpaper/TSEMTA_rel/data/M/type-c/C_P%d/', i);

        parts = strsplit(srcfname, '.txt');
        info(idx).srcfname = parts{1};

        info(idx).cg = to_charge(info(idx).city_num, info(idx).charge_num, info(idx).city, info(idx).charge_node);

    end

end

function cg = to_charge(city_num, charge_num, city, charge)

    ndis_charge = zeros(city_num, city_num);
    left_dis = zeros(city_num, city_num);
    dis_right = zeros(city_num, city_num);
    dis = zeros(charge_num, city_num);
    char_idx = zeros(city_num, city_num);

    for i = 1:city_num

        for j = 1:charge_num
            dis(j, i) = sqrt((city(i, 1) - charge(j, 1)) ^ 2 + (city(i, 2) - charge(j, 2)) ^ 2);
        end

    end

    for i = 1:city_num - 1

        for j = i + 1:city_num
            [mins, min_idx] = min(dis(:, i) + dis(:, j));
            ndis_charge(i, j) = mins;
            ndis_charge(j, i) = mins;

            left_dis(i, j) = dis(min_idx, i);
            dis_right(i, j) = dis(min_idx, j);

            char_idx(i, j) = min_idx;
            char_idx(j, i) = min_idx;
        end

    end

    cg.ndis_charge = ndis_charge;
    cg.left_dis = left_dis;
    cg.dis_right = dis_right;
    cg.char_idx = char_idx;

end

function [comm, res, conv] = init_paras()
    comm.probs = 1;
    comm.runs = 30;
    comm.tasks = 50;
    comm.max_gen = 100;

    res = zeros(comm.tasks, comm.runs, comm.probs);

    conv = zeros(comm.max_gen, comm.runs, comm.probs);
end
